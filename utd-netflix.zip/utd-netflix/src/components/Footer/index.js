import React from 'react';
import { FooterBase } from './styles';

function Footer() {
  return (
    <FooterBase>
      <p>
        Projeto Final UTD
      </p>
    </FooterBase>
  );
}

export default Footer;
